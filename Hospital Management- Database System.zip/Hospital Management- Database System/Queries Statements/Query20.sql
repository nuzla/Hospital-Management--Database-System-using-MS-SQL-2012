SELECT Doctor_ID,COUNT(Appointment_ID) AS Appointment_Count
FROM Appointment
WHERE Appointment_Date_Time='2014-01-18'
GROUP BY Doctor_ID
HAVING COUNT(Appointment_ID)>3;





