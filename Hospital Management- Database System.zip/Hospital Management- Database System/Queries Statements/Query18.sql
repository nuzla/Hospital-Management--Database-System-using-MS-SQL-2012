


SELECT Patient_First_Name, Patient_Last_Name
FROM Patient p, Admitted_Patient adp
WHERE p.Patient_ID = adp.Patient_ID 
AND p.Patient_Address='Colombo' 
AND adp.Ward_No='W001';   

