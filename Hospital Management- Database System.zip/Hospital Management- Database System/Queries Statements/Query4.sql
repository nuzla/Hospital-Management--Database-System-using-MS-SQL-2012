
SELECT Patient_Contact_No 
FROM Patient 
WHERE Patient_ID IN 
(SELECT Patient_ID
 FROM Appointment 
 WHERE	Appointment_Date_Time=dateadd(day,1,convert(date,'2014-01-17'))) 
 	AND Patient_First_Name like('Tom') AND Patient_Last_Name like('Cruise');
