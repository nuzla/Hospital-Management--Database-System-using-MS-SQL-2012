
SELECT * 
FROM Patient 
WHERE Patient_Address='Colombo';



