
SELECT *
FROM Appointment
WHERE datediff(day, Appointment_Date_Time, getdate())=0;


