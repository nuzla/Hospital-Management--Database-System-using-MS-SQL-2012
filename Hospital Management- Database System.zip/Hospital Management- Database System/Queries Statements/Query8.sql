      SELECT count(Appointment_ID) as APPOINTMENTS_TOMORROW
	  FROM Appointment 
	  WHERE Appointment_Date_Time=dateadd(day,1,convert(date,'2014-01-17'));


