
INSERT INTO Appointment VALUES 
('A011','P004','D002','Shamara','Galle','2014-01-19 11:30:00');