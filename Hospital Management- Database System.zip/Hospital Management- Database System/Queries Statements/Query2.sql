

SELECT *
FROM Doctor
WHERE Doctor_Gender='M' AND Doctor_Last_Name='Silva';



