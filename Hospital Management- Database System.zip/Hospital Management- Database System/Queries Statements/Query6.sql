
UPDATE Patient
SET Patient_Address='Galle'
WHERE Patient_First_Name ='James' AND Patient_Last_Name='Bond';
