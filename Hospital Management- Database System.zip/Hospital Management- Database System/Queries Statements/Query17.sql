
DELETE FROM Nurse
WHERE Nurse_First_Name='Miley' AND Nurse_Last_Name='Cyrus';


