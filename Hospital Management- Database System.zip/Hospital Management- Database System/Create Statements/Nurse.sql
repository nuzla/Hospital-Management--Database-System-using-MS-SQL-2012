CREATE TABLE Nurse
(
	Nurse_ID VARCHAR(8) NOT NULL PRIMARY KEY,
	Nurse_First_Name VARCHAR(20) NOT NULL,
	Nurse_Last_Name VARCHAR(20) NOT NULL,
	Nurse_Gender VARCHAR(1) NOT NULL,
	Ward_No VARCHAR(8) NOT NULL FOREIGN KEY REFERENCES Ward(Ward_No),
	Nurse_Type Varchar(20)

);
