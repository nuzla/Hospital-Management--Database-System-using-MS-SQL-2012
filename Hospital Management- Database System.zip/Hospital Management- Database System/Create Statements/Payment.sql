CREATE TABLE Payment
(
	Payment_ID VARCHAR(8) NOT NULL PRIMARY KEY,
	Appoinment_ID VARCHAR(8) NOT NULL FOREIGN KEY REFERENCES Appointment(Appointment_ID),
	Mode_Of_Payment VARCHAR(20) NOT NULL,
	Payment_Date_Time DATETIME NOT NULL,
	Payment_Status VARCHAR(20) NOT NULL,
	Payment_Location VARCHAR(20) NOT NULL,
	Amount INT NOT NULL

);