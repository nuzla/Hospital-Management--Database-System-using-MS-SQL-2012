CREATE TABLE Diagnosis
(
	Diagnosis_ID VARCHAR(8) NOT NULL PRIMARY KEY,
	Appointment_ID VARCHAR(8) NOT NULL FOREIGN KEY REFERENCES Appointment(Appointment_ID),
	Patient_ID VARCHAR(8) NOT NULL FOREIGN KEY REFERENCES Patient(Patient_ID),
	Diagnosis_Status VARCHAR(50) NOT NULL,
	Follow_Up_Methos VARCHAR(50) NOT NULL

);