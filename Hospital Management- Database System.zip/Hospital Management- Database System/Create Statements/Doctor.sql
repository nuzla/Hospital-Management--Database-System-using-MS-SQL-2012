CREATE TABLE Doctor
(
 
	Doctor_ID VARCHAR(8) NOT NULL PRIMARY KEY,
	Doctor_First_Name VARCHAR(20) NOT NULL,
	Doctor_Last_Name VARCHAR(20) NOT NULL,
	Doctor_Gender VARCHAR(1) NOT NULL,
	Doctor_Type VARCHAR(20) NOT NULL,
	Patient_Address VARCHAR(20) NOT NULL,
	Patient_Contact_No VARCHAR(10) NOT NULL
	
);