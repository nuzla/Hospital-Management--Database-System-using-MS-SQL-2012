INSERT INTO Diagnosis VALUES
('DG001','A001','P001','Cancer','Body Scan');

INSERT INTO Diagnosis VALUES
('DG002','A002','P002','Fever','Medication');

INSERT INTO Diagnosis VALUES
('DG003','A003','P003','Pregnancy','5 Weeks');

INSERT INTO Diagnosis VALUES
('DG004','A004','P004','Cancer','Injection Course');

INSERT INTO Diagnosis VALUES
('DG005','A005','P005','Cancer','Body Scan');

INSERT INTO Diagnosis VALUES
('DG006','A006','P006','Cancer','Body Scan');

INSERT INTO Diagnosis VALUES
('DG007','A007','P007','Fever','Medication');

INSERT INTO Diagnosis VALUES
('DG008','A008','P008','Heart Disease','Scan');

INSERT INTO Diagnosis VALUES
('DG009','A009','P009','Fever','Injection Course');

INSERT INTO Diagnosis VALUES
('DG010','A010','P010','Cancer','Injection Course');

