INSERT INTO Appointment VALUES 
('A001','P001','D002','Monisha','Colombo','2014-01-01 09:30:00');

INSERT INTO Appointment VALUES 
('A002','P002','D002','Shamara','Kandy','2014-01-11 08:30:00');

INSERT INTO Appointment VALUES 
('A003','P003','D005','Monisha','Mathara','2014-01-12 10:30:00');

INSERT INTO Appointment VALUES 
('A004','P004','D005','Shamara','Galle','2014-01-05 11:30:00');

INSERT INTO Appointment VALUES 
('A005','P005','D005','Monisha','Jaffna','2014-01-06 12:30:00');

INSERT INTO Appointment VALUES 
('A006','P006','D006','Monisha','Colombo','2014-01-17 13:30:00');

INSERT INTO Appointment VALUES 
('A007','P007','D006','Shamara','Kandy','2014-01-17 14:30:00');

INSERT INTO Appointment VALUES 
('A008','P008','D008','Monisha','Colombo','2014-01-17 15:30:00');

INSERT INTO Appointment VALUES 
('A009','P009','D008','Monisha','Negombo','2014-01-18 16:30:00');

INSERT INTO Appointment VALUES 
('A010','P010','D002','Shamara','Colombo','2014-01-16 23:30:00');

