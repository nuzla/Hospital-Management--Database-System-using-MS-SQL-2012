INSERT INTO Patient VALUES
('P001','Tom','Cruise','M','1998-08-28','Colombo','0712406379');

INSERT INTO Patient VALUES
('P002','James','Bond','M','1992-05-18','Negombo','11239875');

INSERT INTO Patient VALUES
('P003','Julia','Robert','F','1980-04-28','Colombo','0717896379');

INSERT INTO Patient VALUES
('P004','Nuzla','Ismail','F','1982-09-28','Kandy','0776426379');

INSERT INTO Patient VALUES
('P005','Mariam','Saheed','F','1989-08-28','Colombo','0712407419');

INSERT INTO Patient VALUES
('P006','Nisal','Vithanage','M','1992-07-28','Galle','0712469379');

INSERT INTO Patient VALUES
('P007','John','Ebraheem','M','1972-04-19','Colombo','0712407459');

INSERT INTO Patient VALUES
('P008','Marlan','Fernando','M','1984-04-18','Jaffna','0732406379');

INSERT INTO Patient VALUES
('P009','Sharuk','Khan','M','1985-03-04','Colombo','0718606379');

INSERT INTO Patient VALUES
('P010','Kareena','Kapoor','F','1992-04-28','Kandy','0712408079');

