INSERT INTO Nurse VALUES
('N001','Krishani', 'Silva','F','W001','Head');

INSERT INTO Nurse VALUES
('N002','Miley', 'Cyrus','F','W001','General');

INSERT INTO Nurse VALUES
('N003','Micro', 'Noise','F','W002','Head');

INSERT INTO Nurse VALUES
('N004','Kumari', 'Ranathunga','F','W003','Head');

INSERT INTO Nurse VALUES
('N005','Mala', 'Perepa','F','W004','Head');

INSERT INTO Nurse VALUES
('N006','Anna', 'Ibraheem','F','W002','General');

INSERT INTO Nurse VALUES
('N007','Omaya', 'Viduna','F','W003','General');

INSERT INTO Nurse VALUES
('N008','Komini', 'Janaka','F','W004','General');

INSERT INTO Nurse VALUES
('N009','Shalani', 'Perera','F','W001','General');