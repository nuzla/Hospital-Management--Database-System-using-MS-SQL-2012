INSERT INTO Research_Lab VALUES
('R001','D001','Cancer'); 

INSERT INTO Research_Lab VALUES
('R002','D003','Cardiology'); 

INSERT INTO Research_Lab VALUES
('R003','D004','Gynaecology'); 

INSERT INTO Research_Lab VALUES
('R004','D007','Cancer'); 

INSERT INTO Research_Lab VALUES
('R005','D009','Cardiology'); 

INSERT INTO Research_Lab VALUES
('R006','D010','Cancer'); 

