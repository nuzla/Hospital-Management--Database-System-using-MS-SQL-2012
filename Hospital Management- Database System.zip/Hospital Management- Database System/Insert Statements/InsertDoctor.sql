INSERT INTO Doctor Values
('D001','Smith','Silva','M','Researcher','Colombo','123654789');

INSERT INTO Doctor Values
('D002','Kumara','Arachhi','M','Practitioner','Kandy','987654321');

INSERT INTO Doctor Values
('D003','Meena','Silva','F','Researcher','Galle','123249703');

INSERT INTO Doctor Values
('D004','Oshani','Ranathunga','F','Researcher','Jaffna','123789320');

INSERT INTO Doctor Values
('D005','Karunarathna','Silva','M','Practitioner','Colombo','123741963');

INSERT INTO Doctor Values
('D006','Lalith','Vithanage','F','Practitioner','Colombo','951753258');

INSERT INTO Doctor Values
('D007','Madumitha','Selvi','M','Researcher','Negombo','123456987');

INSERT INTO Doctor Values
('D008','Ann','Silva','F','Practitioner','Mathara','951623745');

INSERT INTO Doctor Values
('D009','Mohomed','Ismail','M','Researcher','Kandy','147258369');

INSERT INTO Doctor Values
('D010','Kumara','Munidasa','F','Researcher','Colombo','741852963');

