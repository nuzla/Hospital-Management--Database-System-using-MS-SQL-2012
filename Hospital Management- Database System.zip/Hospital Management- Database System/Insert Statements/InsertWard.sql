INSERT INTO Ward VALUES 
('W001','Meternity Ward','1');

INSERT INTO Ward VALUES 
('W002','Cardiology Ward','2');

INSERT INTO Ward VALUES 
('W003','Accident Ward','3');

INSERT INTO Ward VALUES 
('W004','General Ward','4');
